window.onload = function() {
    callAPI();
}

function callAPI() {
    let xmlhttp = new XMLHttpRequest();
    let url = "https://api.covid19api.com/dayone/country/brazil";

    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            let myArr = JSON.parse(xmlhttp.responseText);
            processaResposta(myArr);
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

function processaResposta(resp) {
    for (let i = 0; i < resp.length; i++)
        document.getElementById("content").innerHTML += "<ul>" +
            "<li>Country:" + resp[i].Country + "</li>" +
            "<li>CountryCode:" + resp[i].CountryCode + "</li>" +
            "<li>Province:" + resp[i].Province + "</li>" +
            "<li>City:" + resp[i].City + "</li>" +
            "<li>CityCode:" + resp[i].CityCode + "</li>" +
            "<li>Lat:" + resp[i].Lat + "</li>" +
            "<li>Lon:" + resp[i].Lon + "</li>" +
            "<li>Confirmed:" + resp[i].Confirmed + "</li>" +
            "<li>Deaths:" + resp[i].Deaths + "</li>" +
            "<li>Recovered:" + resp[i].Recovered + "</li>" +
            "<li>Active:" + resp[i].Active + "</li>" +
            "<li>Date:" + resp[i].Date + "</li>" +
            "</ul>";
    }
}